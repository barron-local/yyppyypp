const mysql = require("mysql2/promise")

const dbConfig = {
  host: process.env.DB_HOST || "localhost",
  user: "root",
  password: "",
  database: "my_app"
}

const db = mysql.createPool(dbConfig)

const initDB = async () => {
  try {
    const rootConn = await mysql.createConnection({
      host: dbConfig.host,
      user: dbConfig.user,
      password: dbConfig.password
    })
    await rootConn.query(`CREATE DATABASE IF NOT EXISTS \`my_app\``)
    await rootConn.end()
    await db.query(`CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50) UNIQUE, pass VARCHAR(50), role VARCHAR(20))`)
    await db.query(`INSERT IGNORE INTO users VALUES (1,'admin','admin','admin'), (2,'user','user','readonly')`)
    await db.query(`CREATE TABLE IF NOT EXISTS roles (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(50))`)
    await db.query(`INSERT IGNORE INTO roles VALUES (1,'admin'), (2,'readonly')`)
    await db.query(`CREATE TABLE IF NOT EXISTS logs (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50), action VARCHAR(50))`)
  } catch (e) {
    console.error("DB Init Error:", e.message)
  }
}
initDB()

module.exports = db
