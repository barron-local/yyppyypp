'use client';
import { useState, useEffect } from 'react';

export default function Home() {
  const getApiUrl = (path) => {
    if (typeof window !== 'undefined') {
      return `http://${window.location.hostname}:5000${path}`;
    }
    return `http://localhost:5000${path}`;
  };

  const [username, setUsername] = useState('');
  const [pass, setPass] = useState('');
  const [user, setUser] = useState(null);
  const [users, setUsers] = useState([]);
  const [newName, setNewName] = useState('');
  const [newPass, setNewPass] = useState('');
  const [newRole, setNewRole] = useState('readonly');
  const [editId, setEditId] = useState(null);
  const [editName, setEditName] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const showErr = (msg) => { setErrorMsg(msg); setTimeout(() => setErrorMsg(''), 4000); };
  const showSuccess = (msg) => { setSuccessMsg(msg); setTimeout(() => setSuccessMsg(''), 4000); };

  // ดึงข้อมูลผู้ใช้ทั้งหมดมาแสดง
  const loadUsers = async (token) => {
    try {
      const res = await fetch(getApiUrl('/api/users'), {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        setUsers(await res.json());
      } else if (res.status === 401) {
        showErr('เซสชั่นหมดอายุ กรุณาเข้าสู่ระบบใหม่');
        handleLogout();
      } else {
        showErr('ไม่สามารถโหลดรายชื่อผู้ใช้ได้');
      }
    } catch (e) {
      showErr('เชื่อมต่อเซิร์ฟเวอร์ไม่ได้');
    }
  };

  // รีเฟรชหน้าแล้วไม่หลุด ดึง token เก่ามาใช้ต่อ
  useEffect(() => {
    const saved = localStorage.getItem('user');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setUser(parsed);
        loadUsers(parsed.token);
      } catch (e) { }
    }
  }, []);

  // ส่งข้อมูลเข้าสู่ระบบ ถ้าผ่านจะได้ token มาเก็บไว้
  const handleLogin = async (e) => {
    e.preventDefault();
    if (!username.trim() || !pass.trim()) {
      showErr('กรุณากรอกชื่อผู้ใช้และรหัสผ่านให้ครบถ้วน');
      return;
    }
    try {
      const res = await fetch(getApiUrl('/api/login'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username.trim(), pass: pass.trim() })
      });
      const data = await res.json();
      if (res.ok) {
        setUser(data);
        localStorage.setItem('user', JSON.stringify(data));
        loadUsers(data.token);
      } else {
        if (res.status === 401) showErr('ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง');
        else showErr(data.message || 'เกิดข้อผิดพลาดในการเข้าสู่ระบบ');
      }
    } catch (err) {
      showErr('เชื่อมต่อเซิร์ฟเวอร์ไม่ได้');
    }
  };

  // แอดมินเพิ่ม user ใหม่
  const handleCreate = async (e) => {
    e.preventDefault();
    if (!newName.trim() || !newPass.trim()) {
      showErr('กรุณากรอกข้อมูลให้ครบถ้วน');
      return;
    }
    if (newPass.length < 4) {
      showErr('รหัสผ่านต้องมีความยาวอย่างน้อย 4 ตัวอักษร');
      return;
    }
    try {
      const res = await fetch(getApiUrl('/api/users'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${user.token}` },
        body: JSON.stringify({ username: newName.trim(), pass: newPass.trim(), role: newRole })
      });
      const data = await res.json();
      if (res.ok) {
        setNewName(''); setNewPass('');
        showSuccess('บันทึกข้อมูลสำเร็จ');
        loadUsers(user.token);
      } else {
        if (res.status === 403) showErr('เฉพาะแอดมินเท่านั้นที่มีสิทธิ์เพิ่ม');
        else showErr(data.message || 'เพิ่มผู้ใช้ไม่สำเร็จ');
      }
    } catch (err) {
      showErr('เชื่อมต่อเซิร์ฟเวอร์ไม่ได้');
    }
  };

  // แก้ไขชื่อผู้ใช้
  const handleEdit = async (id) => {
    if (!editName.trim()) {
      showErr('กรุณากรอกชื่อผู้ใช้');
      return;
    }
    try {
      const res = await fetch(getApiUrl(`/api/users/${id}`), {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${user.token}` },
        body: JSON.stringify({ username: editName.trim() })
      });
      const data = await res.json();
      if (res.ok) {
        setEditId(null);
        showSuccess('แก้ไขข้อมูลสำเร็จ');
        loadUsers(user.token);
      } else {
        if (res.status === 403) showErr('ไม่มีสิทธิ์แก้ไขข้อมูล');
        else showErr(data.message || 'แก้ไขข้อมูลไม่สำเร็จ');
      }
    } catch (err) {
      showErr('เชื่อมต่อเซิร์ฟเวอร์ไม่ได้');
    }
  };

  // ลบผู้ใช้ (เฉพาะ admin)
  const handleDelete = async (id) => {
    if (!confirm('ยืนยันว่าต้องการลบผู้ใช้นี้?')) return;
    try {
      const res = await fetch(getApiUrl(`/api/users/${id}`), {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${user.token}` }
      });
      const data = await res.json();
      if (res.ok) {
        showSuccess('ลบผู้ใช้สำเร็จ');
        loadUsers(user.token);
      } else {
        if (res.status === 403) showErr('เฉพาะแอดมินเท่านั้นที่มีสิทธิ์ลบ');
        else showErr(data.message || 'ลบผู้ใช้ไม่สำเร็จ');
      }
    } catch (err) {
      showErr('เชื่อมต่อเซิร์ฟเวอร์ไม่ได้');
    }
  };

  // ออกจากระบบ ลบ token ทิ้ง
  const handleLogout = async () => {
    try {
      await fetch(getApiUrl('/api/logout'), {
        method: 'POST',
        headers: { Authorization: `Bearer ${user.token}` }
      });
    } catch (e) { }
    localStorage.removeItem('user');
    setUser(null);
  };

  if (!user) {
    return (
      <div className="login-box card">
        <h2 style={{ textAlign: 'center', marginTop: 0 }}>เข้าสู่ระบบ</h2>
        {errorMsg && <div className="alert-error">{errorMsg}</div>}
        <form onSubmit={handleLogin} className="form-col">
          <input
            placeholder="Username"
            value={username}
            onChange={e => setUsername(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={pass}
            onChange={e => setPass(e.target.value)}
            required
          />
          <button type="submit" className="btn-primary">Login</button>
        </form>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="card">
        <div className="header">
          <div>
            <h2 style={{ margin: 0 }}>ระบบจัดการผู้ใช้</h2>
            <small style={{ color: '#666' }}>ผู้ใช้: <b>{user.username} <br />สิทธิ์: {user.role}</b></small>
          </div>
          <button onClick={handleLogout} className="btn-danger">ออกจากระบบ</button>
        </div>

        {errorMsg && <div className="alert-error">{errorMsg}</div>}
        {successMsg && <div className="alert-success">{successMsg}</div>}

        {user.role === 'admin' && (
          <div style={{ background: '#f9fafb', padding: 15, borderRadius: 6, marginBottom: 20 }}>
            <h4 style={{ margin: '0 0 10px 0' }}>เพิ่มผู้ใช้ใหม่</h4>
            <form onSubmit={handleCreate} className="form-row">
              <input
                placeholder="Username"
                value={newName}
                onChange={e => setNewName(e.target.value)}
                required
              />
              <input
                type="password"
                placeholder="Password"
                value={newPass}
                onChange={e => setNewPass(e.target.value)}
                required
              />
              <select value={newRole} onChange={e => setNewRole(e.target.value)}>
                <option value="readonly">readonly</option>
                <option value="editonly">editonly</option>
                <option value="admin">admin</option>
              </select>
              <button type="submit" className="btn-success">เพิ่มผู้ใช้</button>
            </form>
          </div>
        )}

        <h3>รายชื่อผู้ใช้ทั้งหมด ({users.length} คน)</h3>
        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>ชื่อผู้ใช้</th>
                <th>บทบาท</th>
                <th>สถานะ</th>
                <th>เข้าสู่ระบบล่าสุด</th>
                {(user.role === 'admin' || user.role === 'editonly') && <th>จัดการ</th>}
              </tr>
            </thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id}>
                  <td>{u.id}</td>
                  <td>
                    {editId === u.id ? (
                      <input value={editName} onChange={e => setEditName(e.target.value)} />
                    ) : (
                      u.username
                    )}
                  </td>
                  <td>{u.role}</td>
                  <td>{u.status || 'off'}</td>
                  <td>{u.last_login ? new Date(u.last_login).toLocaleString('th-TH') : '-'}</td>
                  {(user.role === 'admin' || user.role === 'editonly') && (
                    <td>
                      {editId === u.id ? (
                        <div style={{ display: 'flex', gap: 4 }}>
                          <button onClick={() => handleEdit(u.id)} className="btn-success">บันทึก</button>
                          <button onClick={() => setEditId(null)} className="btn-cancel">ยกเลิก</button>
                        </div>
                      ) : (
                        <div style={{ display: 'flex', gap: 4 }}>
                          <button onClick={() => { setEditId(u.id); setEditName(u.username); }} className="btn-warning">แก้ไข</button>
                          {user.role === 'admin' && (
                            <button onClick={() => handleDelete(u.id)} className="btn-danger">ลบ</button>
                          )}
                        </div>
                      )}
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

      </div>
    </div>
  );
}