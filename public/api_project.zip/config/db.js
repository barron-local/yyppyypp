const mysql = require("mysql2/promise")

const dbConfig = {
  host: "db",
  user: "root",
  password: "password",
  database: "my_app"
}

const db = mysql.createPool(dbConfig)

const initDB = async () => {
  try {
    const rootConn = await mysql.createConnection({
      host: dbConfig.host,
      user: dbConfig.user,
      password: dbConfig.password
    })
    await rootConn.query(`CREATE DATABASE IF NOT EXISTS \`my_app\``)
    await rootConn.end()
    await db.query(`CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50) UNIQUE, pass VARCHAR(50), role ENUM('admin', 'editonly', 'readonly') DEFAULT 'readonly')`)
    await db.query(`INSERT IGNORE INTO users (id, username, pass, role) VALUES (1,'admin','admin','admin'), (2,'editor','editor','editonly'), (3,'user','user','readonly')`)
    await db.query(`CREATE TABLE IF NOT EXISTS log (idlog INT AUTO_INCREMENT PRIMARY KEY, user_id INT, time DATETIME DEFAULT CURRENT_TIMESTAMP)`)
    await db.query(`CREATE TABLE IF NOT EXISTS status (idstatus INT AUTO_INCREMENT PRIMARY KEY, user_id INT UNIQUE, status ENUM('on', 'off') DEFAULT 'off')`)
  } catch (e) {
    console.error("DB Init Error:", e.message)
  }
}
initDB()

module.exports = db
