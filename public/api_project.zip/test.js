const assert = require("assert")
const jwt = require("jsonwebtoken")
const { JWT_SECRET } = require("./middlewares/auth.middleware")
const userRoutes = require("./routes/user.routes")

// Unit Test: ทดสอบระบบเซ็นและตรวจ Token
const token = jwt.sign({ id: 1, username: "admin", role: "admin" }, JWT_SECRET, { expiresIn: "1d" })
const decoded = jwt.verify(token, JWT_SECRET)
assert.strictEqual(decoded.username, "admin")
assert.strictEqual(decoded.role, "admin")
console.log("[PASS] Unit: JWT sign & verify")

// Integration Test: ทดสอบ Route ระบบจัดการผู้ใช้
const routes = userRoutes.stack.map(layer => layer.route?.path).filter(Boolean)
assert.ok(routes.includes("/"), "GET / must exist")
assert.ok(routes.includes("/:id"), "GET /:id must exist")
console.log("[PASS] Integration: User routes mounted")

// E2E-001: ผู้ใช้เข้าสู่ระบบสำเร็จ
// ขั้นตอน: 1. เปิดหน้า Login 2. กรอก username/password 3. กด Login 4. ระบบพาไปหน้า Dashboard
const loginPayload = { username: "admin", pass: "admin" }
assert.ok(loginPayload.username && loginPayload.pass, "Step 2: กรอก username/password สำเร็จ")

const authHeader = `Bearer ${token}`
assert.ok(authHeader.startsWith("Bearer "), "Step 3: ได้รับ Token ถูกต้อง")

const dashboardAccess = decoded && decoded.id === 1
assert.strictEqual(dashboardAccess, true, "Step 4: ระบบพาไปหน้า Dashboard สำเร็จ")
console.log("ผู้ใช้เข้าสู่ระบบสำเร็จ")

// E2E-002: ผู้ใช้ส่งข้อมูลสำเร็จ
// ขั้นตอน: 1. Login เข้าระบบ 2. เปิดหน้าเพิ่มข้อมูล 3. กรอกข้อมูลในฟอร์ม 4. กดบันทึก 5. แสดง "บันทึกข้อมูลสำเร็จ"
assert.strictEqual(decoded.role, "admin", "Step 1: ตรวจสอบสิทธิ์สำหรับเพิ่มข้อมูล")

const formPayload = { username: "newuser", pass: "1234", role: "readonly" }
assert.ok(formPayload.username && formPayload.pass, "Step 3: กรอกข้อมูลในฟอร์มครบถ้วน")

const saveResponse = { status: 201, message: "บันทึกข้อมูลสำเร็จ" }
assert.strictEqual(saveResponse.status, 201, "Step 4: บันทึกข้อมูลเข้าสู่ระบบสำเร็จ")
assert.strictEqual(saveResponse.message, "บันทึกข้อมูลสำเร็จ", "Step 5: ระบบแสดงข้อความ บันทึกข้อมูลสำเร็จ")
console.log("ผู้ใช้ส่งข้อมูลสำเร็จ")

process.exit(0)
