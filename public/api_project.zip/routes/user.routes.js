const router = require("express").Router()
const db = require("../config/db")
const { auth, adminOnly, canEdit } = require("../middlewares/auth.middleware")

// ดึงข้อมูลหมด เอา status และเวลาล็อกอินล่าสุดมาด้วย
router.get('/', auth, async (req, res) => {
  const [rows] = await db.query(`
    SELECT 
      users.id, 
      users.username, 
      users.role, 
      status.status,
      (SELECT time FROM log WHERE log.user_id = users.id ORDER BY idlog DESC LIMIT 1) AS last_login
    FROM users
    LEFT JOIN status ON users.id = status.user_id
  `)
  res.json(rows)
})

// หาจาก id
router.get('/:id', auth, async (req, res) => {
  const [rows] = await db.query(`
    SELECT users.id, users.username, users.role, status.status
    FROM users
    LEFT JOIN status ON users.id = status.user_id
    WHERE users.id = ?
  `, [req.params.id])
  if (rows.length === 0) return res.status(404).json({ message: "ไม่พบข้อมูลผู้ใช้" })
  res.json(rows[0])
})

// เพิ่ม user
router.post('/', [auth, adminOnly], async (req, res) => {
  const { username, pass, role } = req.body
  if (!username || !pass) return res.status(400).json({ message: "กรุณากรอก username และ password" })

  const [result] = await db.query(
    "INSERT INTO users (username, pass, role) VALUES (?, ?, ?)",
    [username, pass, role || 'readonly']
  )
  res.status(201).json({ id: result.insertId, message: "เพิ่มสำเร็จ" })
})

// แก้ไขข้อมูล
router.patch('/:id', [auth, canEdit], async (req, res) => {
  const { username, pass, role } = req.body
  let result
  if (req.user.role === 'admin' && role) {
    [result] = await db.query("UPDATE users SET username = COALESCE(?, username), pass = COALESCE(?, pass), role = ? WHERE id = ?", [username, pass, role, req.params.id])
  } else {
    [result] = await db.query("UPDATE users SET username = COALESCE(?, username), pass = COALESCE(?, pass) WHERE id = ?", [username, pass, req.params.id])
  }
  if (result.affectedRows === 0) return res.status(404).json({ message: "ไม่พบข้อมูลผู้ใช้ที่จะแก้ไข" })
  res.json({ message: "แก้ไขสำเร็จ" })
})

// ลบ
router.delete('/:id', [auth, adminOnly], async (req, res) => {
  const [result] = await db.query("DELETE FROM users WHERE id = ?", [req.params.id])
  if (result.affectedRows === 0) return res.status(404).json({ message: "ไม่พบข้อมูลผู้ใช้ที่จะลบ" })
  res.json({ message: "ลบสำเร็จ" })
})

module.exports = router
