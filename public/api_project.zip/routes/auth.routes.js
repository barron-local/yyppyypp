const express = require("express")
const jwt = require("jsonwebtoken")
const db = require("../config/db")
const { JWT_SECRET, auth } = require("../middlewares/auth.middleware")
const router = express.Router()

router.post('/login', async (req, res) => {
  const { username, pass } = req.body
  const [users] = await db.query("SELECT * FROM users WHERE username = ? AND pass = ?", [username, pass])
  if (users.length === 0) return res.status(401).json({ message: "ชื่อหรือรหัสผ่านผิด" })

  const user = users[0]

  await db.query("INSERT INTO log (user_id, time) VALUES (?, NOW())", [user.id])

  await db.query(`
    INSERT INTO status (user_id, status) VALUES (?, 'on')
    ON DUPLICATE KEY UPDATE status = 'on'
  `, [user.id])

  const token = jwt.sign({ id: user.id, username: user.username, role: user.role }, JWT_SECRET, { expiresIn: '1d' })
  res.json({ message: "เข้าสู่ระบบสำเร็จ", token, user_id: user.id, username: user.username, role: user.role })
})

router.post('/logout', auth, async (req, res) => {
  await db.query("UPDATE status SET status = 'off' WHERE user_id = ?", [req.user.id])
  res.json({ message: "ออกจากระบบสำเร็จ" })
})

// ดูตัวเอง
router.get('/me', auth, async (req, res) => {
  const [statusRows] = await db.query("SELECT status FROM status WHERE user_id = ?", [req.user.id])
  const [logRows] = await db.query("SELECT time FROM log WHERE user_id = ? ORDER BY idlog DESC LIMIT 1", [req.user.id])

  res.json({
    id: req.user.id,
    username: req.user.username,
    status: statusRows[0]?.status || 'off',
    last_login: logRows[0]?.time || null
  })
})

module.exports = router
