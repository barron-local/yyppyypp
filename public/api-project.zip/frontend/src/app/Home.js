export default function Home() {
  return (
    <main style={{ padding: '40px', fontFamily: 'sans-serif', textAlign: 'center' }}>
      <h1>DevOps Web Application</h1>
      <p>Frontend is running successfully with HTTPS!</p>
    </main>
  );
}
