'use client';
import { useState, useEffect } from 'react';

export default function Home() {
  const [username, setUsername] = useState('');
  const [pass, setPass] = useState('');
  const [user, setUser] = useState(null);
  const [users, setUsers] = useState([]);
  const [newName, setNewName] = useState('');
  const [newPass, setNewPass] = useState('');
  const [newRole, setNewRole] = useState('readonly');
  const [editId, setEditId] = useState(null);
  const [editName, setEditName] = useState('');

  const loadUsers = async () => {
    const res = await fetch('http://localhost:3000/api/users', {
      headers: { Authorization: `Bearer ${user.token}` }
    });
    if (res.ok) setUsers(await res.json());
  };

  useEffect(() => {
    if (user) loadUsers();
  }, [user]);

  // 1. Login
  const handleLogin = async (e) => {
    e.preventDefault();
    const res = await fetch('http://localhost:3000/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, pass })
    });
    const data = await res.json();
    if (res.ok) setUser(data);
    else alert(data.message || 'เข้าสู่ระบบไม่สำเร็จ');
  };

  // 2. Create User (POST)
  const handleCreate = async (e) => {
    e.preventDefault();
    const res = await fetch('http://localhost:3000/api/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${user.token}` },
      body: JSON.stringify({ username: newName, pass: newPass, role: newRole })
    });
    if (res.ok) {
      setNewName(''); setNewPass('');
      loadUsers();
    } else alert('เพิ่มผู้ใช้ไม่สำเร็จ');
  };

  // 3. Edit User (PATCH)
  const handleEdit = async (id) => {
    const res = await fetch(`http://localhost:3000/api/users/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${user.token}` },
      body: JSON.stringify({ username: editName })
    });
    if (res.ok) {
      setEditId(null);
      loadUsers();
    }
  };

  // 4. Delete User (DELETE)
  const handleDelete = async (id) => {
    if (!confirm('ยืนยันการลบ?')) return;
    const res = await fetch(`http://localhost:3000/api/users/${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${user.token}` }
    });
    if (res.ok) loadUsers();
  };

  if (!user) {
    return (
      <div style={{ padding: 20 }}>
        <h2>เข้าสู่ระบบ</h2>
        <form onSubmit={handleLogin}>
          <input placeholder="Username" value={username} onChange={e => setUsername(e.target.value)} /><br /><br />
          <input type="password" placeholder="Password" value={pass} onChange={e => setPass(e.target.value)} /><br /><br />
          <button type="submit">Login</button>
        </form>
      </div>
    );
  }

  return (
    <div style={{ padding: 20 }}>
      <h2>ยินดีต้อนรับ: {user.username} ({user.role})</h2>
      <button onClick={() => setUser(null)}>ออกจากระบบ</button>
      <hr />

      {/* Admin เท่านั้นที่เห็นฟอร์มเพิ่มผู้ใช้ */}
      {user.role === 'admin' && (
        <form onSubmit={handleCreate} style={{ marginBottom: 20 }}>
          <input placeholder="Username" value={newName} onChange={e => setNewName(e.target.value)} required />{' '}
          <input type="password" placeholder="Password" value={newPass} onChange={e => setNewPass(e.target.value)} required />{' '}
          <select value={newRole} onChange={e => setNewRole(e.target.value)}>
            <option value="readonly">readonly</option>
            <option value="admin">admin</option>
          </select>{' '}
          <button type="submit">เพิ่มผู้ใช้</button>
        </form>
      )}

      {/* รายชื่อผู้ใช้ */}
      <h3>รายชื่อผู้ใช้</h3>
      {users.map(u => (
        <div key={u.id} style={{ margin: '8px 0' }}>
          {u.id} | {u.username} | {u.role}{' '}
          {user.role === 'admin' && (
            editId === u.id ? (
              <>
                <input value={editName} onChange={e => setEditName(e.target.value)} />{' '}
                <button onClick={() => handleEdit(u.id)}>บันทึก</button>{' '}
                <button onClick={() => setEditId(null)}>ยกเลิก</button>
              </>
            ) : (
              <>
                <button onClick={() => { setEditId(u.id); setEditName(u.username); }}>แก้ไข</button>{' '}
                <button onClick={() => handleDelete(u.id)}>ลบ</button>
              </>
            )
          )}
        </div>
      ))}
    </div>
  );
}
