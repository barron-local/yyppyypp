const express = require("express")
const jwt = require("jsonwebtoken")
const db = require("../config/db")
const { JWT_SECRET, auth } = require("../middlewares/auth.middleware")
const router = express.Router()

// Login: ตรวจสอบและแจก Token
router.post('/login', async (req, res) => {
  const { username, pass } = req.body
  const [users] = await db.query("SELECT * FROM users WHERE username = ? AND pass = ?", [username, pass])
  if (users.length === 0) return res.status(401).json({ message: "ชื่อหรือรหัสผ่านผิด" })

  const user = users[0]
  const token = jwt.sign({ id: user.id, username: user.username, role: user.role }, JWT_SECRET, { expiresIn: '1h' })
  res.json({ token, username: user.username, role: user.role })
})

// Me: เช็คข้อมูลตนเอง
router.get('/me', auth, (req, res) => res.json(req.user))

module.exports = router
