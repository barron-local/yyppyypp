const router = require("express").Router()
const db = require("../config/db")
const { auth, adminOnly } = require("../middlewares/auth.middleware")

// GET all & by id
router.get('/', auth, async (req, res) => {
  const [rows] = await db.query("SELECT id, username, role FROM users")
  res.json(rows)
})
router.get('/:id', auth, async (req, res) => {
  const [rows] = await db.query("SELECT id, username, role FROM users WHERE id = ?", [req.params.id])
  res.json(rows[0] || {})
})

// POST create user
router.post('/', [auth, adminOnly], async (req, res) => {
  const { username, pass, role } = req.body
  const [result] = await db.query("INSERT INTO users (username, pass, role) VALUES (?, ?, ?)", [username, pass, role || 'readonly'])
  res.status(201).json({ id: result.insertId, message: "เพิ่มสำเร็จ" })
})

// PATCH update username
router.patch('/:id', [auth, adminOnly], async (req, res) => {
  await db.query("UPDATE users SET username = ? WHERE id = ?", [req.body.username, req.params.id])
  res.json({ message: "แก้ไขสำเร็จ" })
})

// DELETE user
router.delete('/:id', [auth, adminOnly], async (req, res) => {
  await db.query("DELETE FROM users WHERE id = ?", [req.params.id])
  res.json({ message: "ลบสำเร็จ" })
})

module.exports = router
