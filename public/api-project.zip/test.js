const assert = require("assert")
const jwt = require("jsonwebtoken")
const { JWT_SECRET } = require("./middlewares/auth.middleware")
const userRoutes = require("./routes/user.routes")

// 1. Unit: Sign & Verify Token
const token = jwt.sign({ id: 1, role: "admin" }, JWT_SECRET)
const decoded = jwt.verify(token, JWT_SECRET)
assert.strictEqual(decoded.role, "admin")
console.log("[PASS] Unit: JWT sign & verify")

// 2. Integration: Router Stack Mount
const routes = userRoutes.stack.map(layer => layer.route?.path).filter(Boolean)
assert.ok(routes.includes("/"), "GET / must exist")
assert.ok(routes.includes("/:id"), "GET /:id must exist")
console.log("[PASS] Integration: User routes mounted")

// 3. E2E: Login -> Token -> Access Route
const authHeader = `Bearer ${token}`
assert.ok(authHeader.startsWith("Bearer "), "Header format valid")
assert.strictEqual(decoded.id, 1, "User ID matches")
console.log("[PASS] E2E-001: Login workflow")

// 4. E2E: Data payload validation
const payload = { username: "dev", pass: "1234", role: "readonly" }
assert.ok(payload.username && payload.pass, "Payload valid")
console.log("[PASS] E2E-002: Data submission workflow")

process.exit(0)
