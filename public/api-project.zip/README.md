# Quick Setup Guide

### 1. ติดตั้ง Docker
```bash
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker $USER && newgrp docker
```

### 2. ตั้งค่า Domain
```bash
echo "127.0.0.1 backend.mydomain.lab frontend.mydomain.lab gitlab.mydomain.lab registry.mydomain.lab" | sudo tee -a /etc/hosts
```

### 3. โคลนโปรเจกต์
```bash
git clone https://gitlab.com/<username>/<repo>.git api
cd api
```

### 4. รันระบบทั้งหมด
```bash
docker compose up -d
```

### 5. ตรวจสอบการทำงาน
```bash
# ตรวจสอบสถานะ container
docker ps

# ทดสอบรันชุดเทส
npm test
```

### 6. นำโค้ดขึ้น GitLab บัญชีใหม่
```bash
rm -rf .git
git init
git branch -M main
git remote add origin https://gitlab.com/<username-ใหม่>/<repo-ใหม่>.git
git add .
git commit -m "initial commit"
git push -u origin main
```

---

### ข้อมูลการเข้าใช้งาน
* **Frontend:** `https://frontend.mydomain.lab`
* **Backend:** `https://backend.mydomain.lab`
* **GitLab UI:** `https://gitlab.mydomain.lab` (ดูรหัสผ่าน root: `docker exec -it gitlab grep 'Password:' /etc/gitlab/initial_root_password`)
* **phpMyAdmin:** `http://<IP-Ubuntu>:8080` (user: `root` / pass: `password`)
* **บัญชีทดสอบ:**
  * Admin: `admin` / `admin`
  * Readonly: `user` / `user`
