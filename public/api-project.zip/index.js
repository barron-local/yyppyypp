const express = require("express")
const cors = require("cors")
const app = express()

app.use(cors())
app.use(express.json())

app.use('/api', require('./routes/auth.routes'))
app.use('/api/users', require('./routes/user.routes'))

app.listen(3000, () => console.log("Server Running on Port 3000"))